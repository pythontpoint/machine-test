package com.app.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.ClientRepo;
import com.app.dao.ProjectRepo;
import com.app.dto.ClientDto;
import com.app.dto.ProjectDto;
import com.app.pojos.Client;
import com.app.pojos.Project;
import com.app.service.IClientService;
import com.app.service.ProjectService;

@RestController
@RequestMapping("/clients")
public class ClientController {
	
	@Autowired
	IClientService clientService ;
	
	@Autowired
	ProjectService projectService ;
	
	@Autowired
	ClientRepo clientRepo ;
	
	@Autowired
	ProjectRepo projectRepo ;
	
	@GetMapping
	public List<Client> getAllClients(){
			return clientService.getAllClients() ;
	}
	
	@PostMapping
	public Client createNewClient(@RequestBody ClientDto clientDto) {
		//ClientDto cl = new ClientDto(clientDto.getClientName()) ;
		System.out.println(clientDto);
		return clientService.createNewClient(new Client(clientDto.getClient_name() , LocalDateTime.now(), "Omkar", null));
	}
	
	@GetMapping("/{id}")
	public Client getParticularClient(@PathVariable Integer id) {
		return clientService.getClientById(id) ;
	}
	
	@PutMapping("/{id}")
	public Client updateClient(@RequestBody ClientDto clientDto,@PathVariable Integer id ) {
		System.out.println(clientDto.getClient_name());
		return clientService.updateClient(clientDto.getClient_name(), id);
	}
	
	@DeleteMapping("/{id}")
	public void deleteClient(@PathVariable Integer id){
		System.out.println("in delete ");
		
		clientService.deleteClient(id);
	}
	
	@PostMapping("/{id}/projects")
	public Client createNewProjectAssignToClient(@PathVariable Integer id , @RequestBody ProjectDto project) {
		//System.out.println(project);
		Project newProject = projectService.createNewProject(project) ;
		//System.out.println(newProject);
		Client currentClient = clientService.getClientById(id) ;
		List<Project> list = currentClient.getProjectList() ;
		List<Project> plist = new ArrayList<Project>();
		System.out.println("here and ");
		
		for(Project p : list) {
			if(projectRepo.existsById(p.getId()))
				plist.add(projectRepo.getById(p.getId())) ;
		}
		
		plist.add(newProject) ;
		currentClient.setProjectList(plist) ;
		return clientRepo.save(currentClient) ;
	}
	

}
