package com.app.dao;

import org.springframework.data.repository.CrudRepository;

import com.app.pojos.User;

public interface UserRepo extends CrudRepository<User, Integer> {
			User getById(int id ) ;
}
