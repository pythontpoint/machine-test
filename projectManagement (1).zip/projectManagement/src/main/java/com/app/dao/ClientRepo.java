package com.app.dao;

import org.springframework.data.repository.CrudRepository;

import com.app.pojos.Client;

public interface ClientRepo extends CrudRepository<Client, Integer>{

	public Client getById(int id );
}
