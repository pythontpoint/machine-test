package com.app.dao;

import org.springframework.data.repository.CrudRepository;

import com.app.pojos.Project;

public interface ProjectRepo extends CrudRepository<Project, Integer>{
			Project getById(int id );
}
