package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.ProjectRepo;
import com.app.dao.UserRepo;
import com.app.dto.ProjectDto;
import com.app.pojos.Project;
import com.app.pojos.User;


@Transactional
@Service
public class ProjectSer implements ProjectService {

	@Autowired
	ProjectRepo projectRepo ;
	
	@Autowired
	UserRepo userRepo ;
	
	@Override
	public Project createNewProject(ProjectDto project) {
		System.out.println("in create new ");
		List<User> list = project.getUserList() ;
		List<User> pList = new ArrayList<User>() ;
		//System.out.println(list);
		for(User u : list) {
			if(userRepo.existsById(u.getId()))
				pList.add(userRepo.getById(u.getId())) ;
		}
		Project project1 = new Project(project.getProjectName(), pList);
		return projectRepo.save(project1) ;
	}

	@Override
	public List<Project> getAllProject() {
		
		return (List<Project>) projectRepo.findAll();
	}

}
