package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.ClientRepo;
import com.app.pojos.Client;

@Service
@Transactional
public class ClientService implements IClientService{
	
	@Autowired
	ClientRepo clientRepo ;
	
	public List<Client> getAllClients(){
		return (List<Client>) clientRepo.findAll() ;
	}
	
	public Client createNewClient(Client client) {
		Client transientClient = clientRepo.save(client) ;
		return transientClient ;
	}
	
	public Client getClientById(int id ) {
		Client transientClient = clientRepo.getById(id) ;
		return transientClient ;
	}
	
	public Client updateClient(String changeName , int id ) {
		Client tClient = clientRepo.getById(id) ;
		tClient.setClient_name(changeName);
		Client nClient = clientRepo.save(tClient) ;
		System.out.println("Nclient "+nClient);
		return nClient ;
	}
	
	public boolean deleteClient(int id ) {
		if(clientRepo.existsById(id)) {
			clientRepo.delete(clientRepo.getById(id));
			return true ;
			
		}
		else 
			return false ;
	}
	
	

}
