package com.app.service;

import java.util.List;

import com.app.dto.ProjectDto;
import com.app.pojos.Project;

public interface ProjectService{
		Project	createNewProject(ProjectDto project ) ;
		
		List<Project> getAllProject() ;
}
