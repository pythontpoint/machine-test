package com.app.service;

import java.util.List;

import com.app.pojos.Client;

public interface IClientService {

	List<Client> getAllClients();
	
	Client createNewClient(Client client);
	
	Client getClientById(int id ) ;
	
	Client updateClient(String changeName , int id );
	
	boolean deleteClient(int id ) ;

}
